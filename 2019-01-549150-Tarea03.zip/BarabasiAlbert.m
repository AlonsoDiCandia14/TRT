clc; clear all;
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Scale-free networks: Barabasi-albert Algorithm
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Number of nodes in the network
NumNodes        = 30;
% It can not be greater than 2, because first we choose two nodes.
MinimumDegree   = 1;
% Execute the code
% Preallocate memory for the adjacency matrix and define that nodes 1 and 2
% are initially linked
AdjacencyMatrix         = zeros(NumNodes,NumNodes);
AdjacencyMatrix(1,2)    = 1;
AdjacencyMatrix(2,1)    = 1;

% Loop over the number of nodes to generate a scale free network
for i=3:NumNodes
    % Initial definitions
    DegreeNodei         = 0;
    j                   = 1;
    % Loop over the nodes already connected to create new links using the
    % preferencial connection concept
    while (j<i)
        % Compute the connection probability of the jth node:
        % First determine the number of connections of the jth node
        NodesDegree             = sum( AdjacencyMatrix(:,j) );
        % Next, compute the total number of connections in the graph
        TotalNumberConnections  = sum(AdjacencyMatrix(:))/2;
        % Finally, determine the connection probability
        ConnectionProbability   = NodesDegree/TotalNumberConnections;
        % Randomly include a new link into the graph based upon the
        % connection probability
        if ( rand<=ConnectionProbability  && AdjacencyMatrix(i,j)==0 )
            DegreeNodei             = DegreeNodei + 1;
            AdjacencyMatrix(i,j)    = 1;
            AdjacencyMatrix(j,i)    = 1;
        end
        % If node degree is less than the minimum keep on iterating to add
        % more nodes
        if ( j==(i-1) && DegreeNodei<MinimumDegree )
            j=0;
        end
        j=j+1;
    end
end
